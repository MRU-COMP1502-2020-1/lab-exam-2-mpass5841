package lsystems;

public class A_Q extends LRule {

	public A_Q() {
		
	}
	
	@Override
	public char getMatch() {
		// TODO Auto-generated method stub
		return 'A';
	}

	@Override
	public char[] getBody() {
		// TODO Auto-generated method stub
		char[] c = { 'Q' };
		return c;
	}

}
