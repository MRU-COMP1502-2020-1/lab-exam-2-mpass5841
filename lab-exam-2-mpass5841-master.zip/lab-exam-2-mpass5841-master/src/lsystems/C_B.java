package lsystems;

public class C_B extends LRule {

	public C_B() {
		
	}
	
	@Override
	public char getMatch() {
		// TODO Auto-generated method stub
		return 'C';
	}

	@Override
	public char[] getBody() {
		// TODO Auto-generated method stub
		char[] c = { 'B' };
		return c;
	}

}
