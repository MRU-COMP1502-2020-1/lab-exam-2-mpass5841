package lsystems;

public class A_X extends LRule {

	public A_X() {
		
	}
	
	@Override
	public char getMatch() {
		// TODO Auto-generated method stub
		return 'A';
	}

	@Override
	public char[] getBody() {
		// TODO Auto-generated method stub
		char[] c = { ' ' };
		return c;
	}

}
