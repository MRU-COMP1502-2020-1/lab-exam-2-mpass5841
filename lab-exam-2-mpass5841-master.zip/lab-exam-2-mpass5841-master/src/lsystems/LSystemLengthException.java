package lsystems;

public class LSystemLengthException extends Exception {

}
