package lsystems;

public class A_A extends LRule{

	public A_A() {
		
	}
	
	@Override
	public char getMatch() {
		// TODO Auto-generated method stub
		return 'A';
	}

	@Override
	public char[] getBody() {
		// TODO Auto-generated method stub
		char[] c = { 'A' };
		return c;
	}

}
